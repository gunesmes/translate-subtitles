from .ts import TranslateSubtitle
from .translator import ts